def sumar(x, y):
    return x + y
