from utils import sumar


def test_sumar():
    assert sumar(1, 1) == 2